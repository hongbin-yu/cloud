What is the "classes" folder?
-----------------------------

This folder is for Java developers wishing to create their custom features.
You can put your custom Java classes in this folder and they will be 
automatically picked up on the next execution (provided you are using
the supplied .bat or .sh launch script).

If you package your classes into a Jar file, put that file in the "lib" folder
instead.

You can safely delete this file.